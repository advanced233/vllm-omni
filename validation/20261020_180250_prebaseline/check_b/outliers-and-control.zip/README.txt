检查B异常音频包：4条离群 + 1条正常对照。音频未裁剪或改音量。
建议先听05正常对照，再听01至04。保持同一正常音量，勿为了听低能量片段突然大幅提高耳机音量。
01 row18_codes_s300：实际seed318，23.220秒，目标 Large brown dog walks up a blue staircase.
02 row14_audio_s0：实际seed14，19.691秒。
03 row14_audio_s400：实际seed414，16.718秒。
04 row14_codes_s400：实际seed414，17.926秒。
02–04目标 Elvis Presley is often called the "King of Rock and Roll".
05 row18_codes_s0：正常对照，实际seed18，目标同01。
文件夹s后数字是seed基数，实际请求seed=基数+行号。
重点判断是否存在清晰目标语音、是否只有底噪或语音缺失。辅助ASR不能代替听检。
